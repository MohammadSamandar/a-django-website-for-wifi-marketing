from django.apps import AppConfig


class DjfSurveysConfig(AppConfig):
    name = "surveys"
    verbose_name = "نظرسنجی"
    default_auto_field = "django.db.models.BigAutoField"
